import java.awt.*;
import java.awt.event.*;
public class RightButtonListener implements ActionListener
{
	MainFrame manager;
	public RightButtonListener(MainFrame m)
	{
		manager = m;
	}
	@Override
	public void actionPerformed(ActionEvent ae)
	{
		manager.removeBoard();
		manager.makeNewGame();
	}
}