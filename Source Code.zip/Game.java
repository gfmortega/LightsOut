import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Random;
import java.lang.Math.*;
public class Game extends Container
{
	private MainFrame manager;
	private int width;
	private int height;
	
	private Tile[][] lights;
	private ArrayList<Integer> initialState;
	private int tally;
	public boolean gameIsWon;
	
	public Game(int h, int w, MainFrame m)
	{
		manager = m;
		height = h;
		width = w;		
		this.setLayout(new GridLayout(h,w)); //number of rows first then number of columns
		gameIsWon = false;
		
		lights = new Tile[height][width];
		for(int i = 0; i < height; i++)
			for(int j = 0; j < width; j++)
				lights[i][j] = new Tile(i,j,this);
				
		for(int i = 0; i < height; i++)
			for(int j = 0; j < width; j++)
				this.add(lights[i][j]);
				
		tally = 0;
		
		initialState = new ArrayList<Integer>();
		newGame();
	}
	private void newGame()
	{
		Random rand = new Random();
		
		int lightsCount = width*height;
		
		boolean[] chosen = new boolean[lightsCount];
		for(int i = 0; i < lightsCount; i++)
			chosen[i] = false;
			
		int lightsChoices = (rand.nextInt()%(2*lightsCount/3)+2*lightsCount/3)%(2*lightsCount/3) + Math.max(lightsCount/6,2);
		
		manager.setMinimalMoves(lightsChoices);
		manager.refreshMinLabel();
		
		while(lightsChoices>0)
		{
			int press = rand.nextInt(lightsCount);
			if(!chosen[press])
			{
				chosen[press] = true;
				initialState.add(press);
				lightsChoices--;
			}
		}
		
		resetGame();
	}
	public void resetGame()
	{
		for(int i = 0; i < height; i++)
			for(int j = 0; j < width; j++)
				if(lights[i][j].isOn)
					lights[i][j].flip();
					
		for(int k = 0; k < initialState.size(); k++)
			//System.out.println(initialState.get(k)%height + " " + (initialState.get(k)/height)%width);
			pushTile(initialState.get(k)/width,initialState.get(k)%width);
	}
	public void pushTile(int i, int j)
	{
		lights[i][j].flip();
		if(i-1 >= 0)
			lights[i-1][j].flip();
		if(i+1 < height)
			lights[i+1][j].flip();
		if(j-1 >= 0)
			lights[i][j-1].flip();
		if(j+1 < width)
			lights[i][j+1].flip();
			
		if(tally==0)
		{
			JOptionPane.showMessageDialog(null,"Congrats, you won!");
			gameIsWon = true;
		}
	}
	public void adjustTally(boolean on)
	{
		if(on)
			tally--;
		else
			tally++;
	}
	public void logMove()
	{
		manager.incrementCurrentMoves();
		manager.refreshCurrLabel();
	}
}