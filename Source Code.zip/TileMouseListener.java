import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class TileMouseListener implements MouseListener
{
	Tile myTile;
	public TileMouseListener(Tile m)
	{
		myTile = m;
	}
	@Override 
	public void mousePressed(MouseEvent	e)
	{
		if(myTile.isGameWon())
			return;
			
		myTile.logMove();
		myTile.pushMe();
	}
	@Override 
	public void mouseClicked(MouseEvent e){}
	@Override 
	public void mouseExited(MouseEvent e){}
	@Override 
	public void mouseReleased(MouseEvent e){}
	@Override 
	public void mouseEntered(MouseEvent e){}
}