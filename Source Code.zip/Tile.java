import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Tile extends JComponent
{
	public boolean isOn;
	
	private static final Color onColor = Color.YELLOW;
	private static final Color offColor = Color.WHITE;
	private static final Color borderColor = Color.BLACK;
	private static final double margin = 0.025;
	
	private Game manager;
	private int i;
	private int j;
	
	public Tile(int x, int y, Game g)
	{
		manager = g;
		i = x;
		j = y;
		isOn = false;
		this.addMouseListener(new TileMouseListener(this));
	}
	@Override
	protected void paintComponent(Graphics g)
	{
		int t = MainFrame.tileSize;
		g.setColor(borderColor);
		g.fillRect(0,0,t,t);
		g.setColor(isOn ? onColor : offColor);
		g.fillRect((int)(t*margin),(int)(t*margin),(int)(t-2*t*margin),(int)(t-2*t*margin));
	}
	public boolean flip()
	{
		manager.adjustTally(isOn);
		isOn = !isOn;
		repaint();
		return isOn;
	}
	public void pushMe()
	{
		manager.pushTile(i,j);
	}
	public void logMove()
	{
		manager.logMove();
	}
	public boolean isGameWon()
	{
		return manager.gameIsWon;
	}
}