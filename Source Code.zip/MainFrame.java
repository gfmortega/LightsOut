import javax.swing.*;
import java.awt.*;
public class MainFrame extends JFrame
{
	public static final int tileSize = 50;
	
	private int gridWidth;
	private int gridHeight;
	private int frameWidth;
	private int frameHeight;
	
	private Container contentPane;
	private Container topPane;
	private Container botPane;
	
	private Game gameState;
	
	private int minimalMoves;
	private int currentMoves;
	private JLabel minDisplay;
	private JLabel currDisplay;
	
	private JButton resetButton;
	private JButton newGameButton;
	
	public MainFrame()
	{
		boolean invalid_N = true;
		int w = 4, h = 4;
		while(invalid_N)
		{
			try
			{
				String s = JOptionPane.showInputDialog(null,"Create w x h board.  Input w and h, space-separated, each from 1 to 10");
				if(s==null)
					return;
				String[] wh = s.split("\\s+");
				w = Integer.parseInt(wh[0]);
				h = Integer.parseInt(wh[1]);
				invalid_N = !((1 <= w && w <= 10)&&(1 <= h && h <= 10));
			}
			catch(Exception e)
			{
			}
		}
		gridWidth = w;
		gridHeight = h;
		frameWidth = w*tileSize + 10; //to account for the buttons and frames and stuff
		frameHeight = h*tileSize + 75;
		
		contentPane = this.getContentPane();
		contentPane.setLayout(new BorderLayout());
		topPane = new Container();
		botPane = new Container();
		
		topPane.setLayout(new GridLayout(1,2));
		minimalMoves = 0;
		currentMoves = 0;
		minDisplay = new JLabel();
		currDisplay = new JLabel();
		
		minDisplay.setHorizontalAlignment(JLabel.CENTER);
		currDisplay.setHorizontalAlignment(JLabel.CENTER);
		topPane.add(minDisplay);
		topPane.add(currDisplay);
		
		makeNewGame();
		
		botPane.setLayout(new GridLayout(1,2));
		resetButton = new JButton("Reset");
		newGameButton = new JButton("New");
		resetButton.addActionListener(new LeftButtonListener(this));
		newGameButton.addActionListener(new RightButtonListener(this));
		botPane.add(resetButton);
		botPane.add(newGameButton);
		
		contentPane.add(topPane,BorderLayout.NORTH);
		contentPane.add(botPane,BorderLayout.SOUTH);
		
		this.setSize(frameWidth,frameHeight);
		this.setTitle("Lights Out");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	public void makeNewGame()
	{
		gameState = new Game(gridHeight,gridWidth,this);
		contentPane.revalidate();
		contentPane.add(gameState,BorderLayout.CENTER);
		
		currentMoves = 0;
		refreshCurrLabel();
	}
	public void incrementCurrentMoves()
	{
		currentMoves++;
	}
	public void setMinimalMoves(int m)
	{
		minimalMoves = m;
	}
	public void refreshMinLabel()
	{
		minDisplay.setText("Goal: "+minimalMoves);
	}
	public void refreshCurrLabel()
	{
		currDisplay.setText("Current: "+currentMoves);
	}
	public void resetGame()
	{
		currentMoves = 0;
		refreshCurrLabel();
		gameState.gameIsWon = false;
		gameState.resetGame();
		revalidate();
	}
	public void removeBoard()
	{
		contentPane.remove(gameState);
	}
	public boolean isGameWon()
	{
		return gameState.gameIsWon;
	}
}