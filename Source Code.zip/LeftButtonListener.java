import java.awt.*;
import java.awt.event.*;
public class LeftButtonListener implements ActionListener
{
	MainFrame manager;
	public LeftButtonListener(MainFrame m)
	{
		manager = m;
	}
	@Override
	public void actionPerformed(ActionEvent ae)
	{
		manager.resetGame();
	}
}